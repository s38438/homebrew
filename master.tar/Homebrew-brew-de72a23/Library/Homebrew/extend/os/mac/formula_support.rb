# frozen_string_literal: true

class KegOnlyReason
  def valid?
    true
  end
end
