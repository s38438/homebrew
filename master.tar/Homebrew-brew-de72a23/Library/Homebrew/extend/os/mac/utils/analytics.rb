# frozen_string_literal: true

module Utils
  module Analytics
    class << self
      def custom_prefix_label
        "non-/usr/local"
      end
    end
  end
end
