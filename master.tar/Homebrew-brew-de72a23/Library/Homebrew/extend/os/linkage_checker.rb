# frozen_string_literal: true

require "extend/os/linux/linkage_checker" if OS.linux?
