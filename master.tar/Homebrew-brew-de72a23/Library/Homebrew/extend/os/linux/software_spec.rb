# frozen_string_literal: true

class BottleSpecification
  def skip_relocation?
    false
  end
end
