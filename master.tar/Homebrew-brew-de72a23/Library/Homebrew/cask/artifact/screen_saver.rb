# frozen_string_literal: true

require "cask/artifact/moved"

module Cask
  module Artifact
    class ScreenSaver < Moved
    end
  end
end
