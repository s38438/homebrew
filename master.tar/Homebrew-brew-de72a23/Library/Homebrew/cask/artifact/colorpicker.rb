# frozen_string_literal: true

require "cask/artifact/moved"

module Cask
  module Artifact
    class Colorpicker < Moved
    end
  end
end
