# frozen_string_literal: true

require "cask/artifact/moved"

module Cask
  module Artifact
    class VstPlugin < Moved
    end
  end
end
