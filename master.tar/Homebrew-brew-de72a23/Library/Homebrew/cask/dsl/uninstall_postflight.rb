# frozen_string_literal: true

module Cask
  class DSL
    class UninstallPostflight < Base
    end
  end
end
