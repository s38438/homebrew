# frozen_string_literal: true

require "compat/cask/dsl/version"
