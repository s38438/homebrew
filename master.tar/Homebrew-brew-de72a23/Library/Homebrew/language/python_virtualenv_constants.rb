# frozen_string_literal: true

PYTHON_VIRTUALENV_URL =
  "https://files.pythonhosted.org/packages/a9/8a" \
  "/580c7176f01540615c2eb3f3ab5462613b4beac4aa63410be89ecc7b7472" \
  "/virtualenv-16.7.2.tar.gz"
PYTHON_VIRTUALENV_SHA256 =
  "909fe0d3f7c9151b2df0a2cb53e55bdb7b0d61469353ff7a49fd47b0f0ab9285"
