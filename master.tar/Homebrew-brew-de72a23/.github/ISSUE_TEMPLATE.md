Please fill out one of the templates on: https://github.com/Homebrew/brew/issues/new/choose

If you want to ask a question please do so on our Discourse: https://discourse.brew.sh

We will close issues asking questions without comment.